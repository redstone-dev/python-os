version = 1.0

boot_text = f"""
PythonOS {version}
"""

default_user = ("newuser", "newpswd")