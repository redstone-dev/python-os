from pyos_sdk import PyOSApplication, PyOS_Error, throw
from os import system as shell

def cmd_lookup(cmd):
    try:
        return {
            ".launch": "self.run_program({0}{1})",
            ".help": "self.help()",
            ".exit": "self.exit()",
            ".restore": "self.restore_session()"
        }[cmd]
    except(KeyError):
        return throw(PyOS_Error("Invalid command!", fatal=False))

class Terminal(PyOSApplication):
    def __init__(self, /, space=3, user=None) -> None:
        # Provide a global 'term' object for use in the terminal
        global term
        term = self
        # Required things
        self.procname = "PythonOS Terminal"
        self.space = space
        self.user = user
        self.sessions = []
        self.lines = []
        self.logs = []

        super().__init__(space=self.space, user=user)
        self.main()
        return None
    
    def run_program(self, path: str):
        namespace = path.split(":")[0]
        app_type = path.split(":")[1]

        try:
            if not namespace == "sysprg":
                eval(f"import {namespace}")
            
            try:
                a = app_type(space=3, user=self.user)
            except:
                throw(PyOS_Error("An unknown error occurred in the application which caused it to crash."))
        except(ImportError):
            self.write(f"Error: Failed to import {namespace}, possibly because it doesn't exist")
        except(TypeError):
            self.write(f"Error: Possibly too many args passed to {app_type}")
    
    def help(self):
        self.run_program("sysprg:Help")
    
    def write(self, text, silent=False):
        import datetime
        if not silent:
            print(text)
        """
        The general format for self.write() and self.log() is:
            <time> [<source>] <text>
        'source' is only included if it's not from the main output
        """
        self.lines.append(f"{datetime.datetime.now()} {text}")
        self.logs.append("...")

    def log(self, content):
        import datetime
        self.lines.append(f"{datetime.datetime.now()} [Logs] {str(content)} (Generated from self.log(), read the logs for more info)")
        self.logs[len(self.lines)]

    def evaluate(self, expression):
        if not expression == "":
            self.write(eval(expression))
        else:
            throw(PyOS_Error("Empty expression not allowed"))
    
    def exit(self):
        import sys
        if self.space < 3:
            self.write("Can not exit terminal if it is acting as the shell.")
        else:
            self.write("Saving session...")
            self.sessions.append({
                "term_output" : self.lines,
                "logs" : self.logs
            })
            with open("system_support/Terminal.log", 'wt') as log:
                import datetime
                session_saved_time = datetime.datetime.now()
                log.seek(0)
                log.write(f"Output for session saved at {session_saved_time}\n")
                self.sessions[""]
                log.write("End of dump\n")
            sys.exit(0)
    
    def main(self) -> int:
        self.write("In this terminal you can type plain Python, and it acts as a REPL, or you can type commands starting with '.' to do other things with PythonOS.")
        cmd = None
        if self.space == 3:
            try:
                while not cmd == ".exit":
                    cmd = input(f"{self.user}> ")
                    self.evaluate(cmd)
            except(KeyboardInterrupt):
                self.exit()
        else:
            while not cmd == ".shutdown":
                try:
                    cmd = input("> ")
                    self.evaluate(cmd)
                except(KeyboardInterrupt): pass
            
        return 0

class FileViewer(PyOSApplication):
    import os
    def __init__(self, /, space=3, user=None) -> None:
        self.procname = "File Viewer"
        super().__init__(space, user)
        self.main()
    
    def list(dirname: str):
        # From https://www.geeksforgeeks.org/os-walk-python/
        import os
        if __name__ == "__main__":
            for (root,dirs,files) in os.walk(dirname, topdown=True):
                print (root)
                print (dirs)
                print (files)
                print ('--------------------------------')

    def main(self): 
        PyOS_Error("Not implemented yet")
        return "10" # until I finish Terminal

class PkgManager(PyOSApplication):
    def __init__(self, /, space, user) -> None:
        super().__init__(space, user)
        self.main()
    
    def main(self):
        return throw(PyOS_Error("Not implemented yet"))

if __name__ == "__main__":
    shell('python3 system.py')